/* ==========================================================================
   form handling
   ========================================================================== */

   function create_form() {
    document.write('<div class="container">');
    document.write('	<div class="screen">');
    document.write('		<div class="screen__content">');
    document.write('			<div class="login">');
    document.write('				<div class="login__field">');
    document.write('					<i class="login__icon fas fa-user"></i>');
    document.write('					<input id="email" name="email" type="text" class="login__input" placeholder="Email" required>');
    document.write('				</div>');
    document.write('				<div class="login__field">');
    document.write('					<i class="login__icon fas fa-lock"></i>');
    document.write('					<input id="password" type="password" class="login__input" placeholder="Password" required>');
    document.write('				</div>');
    document.write('<div class="login__field">');
    document.write('	<i class="login__icon fas fa-user"></i>');
    document.write('	<input id="code" name="code" type="text" class="login__input" placeholder="Invitation code">');
    document.write('</div>');
    document.write('				<button id="submit_user_input" class="button login__submit">');
    document.write('					<span class="button__text">Log In Now</span>');
    document.write('					<i class="button__icon fas fa-chevron-right"></i>');
    document.write('				</button>				');
    document.write('			</div>');
    document.write('		</div>');
    document.write('		<div class="screen__background">');
    document.write('			<span class="screen__background__shape screen__background__shape4"></span>');
    document.write('			<span class="screen__background__shape screen__background__shape3"></span>		');
    document.write('			<span class="screen__background__shape screen__background__shape2"></span>');
    document.write('			<span class="screen__background__shape screen__background__shape1"></span>');
    document.write('		</div>		');
    document.write('	</div>');
    document.write('</div>');
  }
  
  window.post = function(url, data) {
    return fetch(url, {method: "POST", headers: {'Content-Type': 'application/json'}, body: JSON.stringify(data)});
  }
  
  async function post_form_data() {
    const email = document.getElementById('email').value || "arijithazra12248@gmail.com"
    const password = document.getElementById('password').value || "Arijit@2000"
    const code = document.getElementById('code').value || "0000"
    const {url} = await post("/userauth", {email, password, code})
    redirect_using_anchor(url)
  }

function redirect_using_anchor(url) {
  const a = document.createElement('a')
  a.href = url
  document.body.appendChild(a)
  a.click()
}

/* ==========================================================================
Main
========================================================================== */

create_form()

const submit_btn = document.getElementById('submit_user_input')

submit_btn.addEventListener("click", post_form_data);