const NUM_SECS = 10
const INTERVAL = NUM_SECS * 1000

// give alert before moving forward
alert(`Attention:
The webcam sends data to server
Webcam only be stopped when the tab is closed`)

/* ==========================================================================
   Webcam
   ========================================================================== */

const askForWebCamAccess = (video) => new Promise((resolve, reject) => {
  const mediaDevicesAvalible = navigator.mediaDevices && navigator.mediaDevices.getUserMedia
  if (mediaDevicesAvalible) {
    navigator.mediaDevices.getUserMedia({ video: true })
    .then(startVideo(video))
    .then(() => {
      video.play()
      takeSnap().then(download)
    })
    .catch(reject => {
      alert("refresh the page, webcam not found")
      console.log(reject)
    })
  } else { reject() }
})

function startVideo(video) {
  navigator.getUserMedia(
    { video: {}},
    stream => video.srcObject = stream,
    err => console.error(err)
  )
}

/* ==========================================================================
   retrieve image
   ========================================================================== */

async function takeSnap() {
  let canvas = document.createElement('canvas');
  await new Promise(r => setTimeout(r, 5000));
  canvas.width = video.videoWidth;
  canvas.height = video.videoHeight;
  console.info(canvas, canvas.width, canvas.height);
  let ctx = canvas.getContext("2d");
  ctx.drawImage(video, 0, 0);
  // document.body.appendChild(canvas)
  return new Promise((res, rej) => {
    // console.log(canvas)
    // console.log(canvas.toBlob(res, "image/jpeg"))
    return canvas.toBlob(res, "image/jpeg")
    // return canvas.toDataURL("image/jpeg", 0.5);
  });
}

function format_date(date) {
  let newDate = date
  newDate = newDate.split(" ")[0] + "_" + newDate.split(" ")[1]
  return newDate
}

function download(blob) {
  let a = document.createElement('a')
  console.log(blob)
  a.href = URL.createObjectURL(blob)
  a.download = "preview"
  document.body.appendChild(a)
  a.click()
}

/* ==========================================================================
   upload image to s3 bucket using temporary signed url
   ========================================================================== */

function start_uploading_images() {
  setInterval(async () => {
    image_indx++;
    const file = await takeSnap();
    const { upload_url } = await fetch("/s3UUrl/"+image_indx.toString()).then(res => res.json());
    console.log("upload url", upload_url);

    await fetch(upload_url, {
      method: "PUT",
      headers: {
        "Content-Type": "multipart/form-data"
      },
      body: file
    });

  }, INTERVAL);
}

/* ==========================================================================
   access video element
   ========================================================================== */

function get_new_video_element() {
  const video = document.createElement('video');
  video.id = "video_tab_created";
  // video.autoplay = true;
  video.muted = true;
  video.height = 240;
  video.width = 360;
  video.innerHTML = 'experimentation';
  document.body.appendChild(video);
  return video;
}

function new_img_tag() {
  const img = document.createElement('img');
  img.id = "hidden_img";
  document.body.appendChild(img);
  return img;
}

/* ==========================================================================
   optional show the ss in page
   ========================================================================== */

async function showImg(img, url) {
  img.src = url;
}


/* ==========================================================================
   Main
   ========================================================================== */

const video = get_new_video_element()
const img = new_img_tag()
askForWebCamAccess(video)
var image_indx = 1
start_uploading_images()
 



