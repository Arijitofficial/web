import aws from 'aws-sdk'
import crypto from 'crypto'
import { promisify } from "util"

const randomBytes = promisify(crypto.randomBytes)


export async function create_s3_instance(region, accessKeyId, secretAccessKey) {
  const s3 = new aws.S3({
    region,
    accessKeyId,
    secretAccessKey,
    signatureVersion: 'v4'
  })
  return s3;
}

export async function generateUploadURL(s3, bucketName, expires_in_seconds, i) {
  if(!process.env.USER) return ""
  const imageName = process.env.INVC + process.env.USER + i.toString()

  const params = ({
    Bucket: bucketName,
    Key: imageName,
    Expires: expires_in_seconds
  })
  
  const uploadURL = await s3.getSignedUrlPromise('putObject', params)
  return uploadURL
}

export async function generateDownloadURL(s3, bucketName, numOfObjects) {
  const imageName = "*"

  const params = ({
    Bucket: bucketName,
    MaxKeys: numOfObjects,
  })
  var downloadURL_promise = {}
  try {
    downloadURL_promise = await s3.getSignedUrlPromise('listObjectsV2', params)
  } catch(ex) {
    console.log(ex)
    return {}
  }
  // const downloadURL_direct = await s3.getSignedUrl('getObject', params)
  // console.log(downloadURL_direct, downloadURL_promise)
  return downloadURL_promise
}