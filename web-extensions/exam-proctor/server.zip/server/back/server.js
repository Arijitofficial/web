import dotenv from 'dotenv'
import express from 'express'
import { create_s3_instance, generateUploadURL, generateDownloadURL } from './signedURL.js'
import { signUp,verify,signIn } from './auth.cjs'
import path from 'path'
import ejs from 'ejs'
import { fileURLToPath } from 'url';
import { dirname } from 'path';
// configure .env
dotenv.config()

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(dirname(__filename));
console.log(__dirname)


// constant variables
const region = process.env.REGION
const bucketName = process.env.BUCKET
const accessKeyId = process.env.AWS_ACCESS_KEY_ID
const secretAccessKey = process.env.AWS_SECRET_ACCESS_KEY

const UserPoolId = process.env.USERPOOLID
const ClientId = process.env.CLIENTID

// instansiate express
const app = express()
app.set('views', path.join(__dirname, 'front'))
app.set('view engine', "ejs")
// create s3 instance
const s3 = await create_s3_instance(region, accessKeyId, secretAccessKey)

// app.use(express.static('front'))


app.get('/exam/:id', async (req, res) => {
  // console.log(req.params)
  if(!process.env.T_ID || process.env.T_ID!=(req.params.id)) {
    console.log("redirection to same page")
    res.redirect('/')
  }
  else res.render("dummy_exam");
})


/* ==============================================================================
sign in
=============================================================================== */
app.get('/sign-in', (req, res) => {
  res.send("HTML will be injected by extension");
})

// create application/json parser
var jsonParser = express.json()

app.post('/userauth', jsonParser, async (req, res) => {
  var email = req.body.email;
  var password = req.body.password;
  var {statusCode, response} = await signIn(email,password);
  if(statusCode<300) {
    process.env["USER"] = response["email"];
    process.env["T_ID"] = response["uid"];
    process.env["INVC"] = req.body.code;
  }
  else res.Status("500").send("Wrong credentials")
  res.redirect('/exam/'+ response["uid"].toString())
})


/* ==============================================================================
photo upload and downlad
=============================================================================== */

app.get('/s3DUrl', async (req, res) => {
  const numOfObjects = Number(req.params.numOfObjects)
  var download_urls = await generateDownloadURL(s3, bucketName, numOfObjects)
  console.log(download_url)
  res.send({download_url})
})


app.get('/s3UUrl/:i', async (req, res) => {
  var i = req.params.i
  const upload_url = await generateUploadURL(s3, bucketName, 60, i)
  res.send({upload_url})
})



/* ==============================================================================
hosting
=============================================================================== */
app.get('/', (req, res) => {
  console.log(req.params)
  res.redirect('/sign-in');
})

app.listen(8080, () => console.log("listening on port 8080"))